import{a7 as a,J as o,C as t}from"./b_z34-op.js";const i=a((n,r)=>{const e=o("user").value;if(!o("token").value)return t("/login");if(!e||e.role!=="ADMIN")return t("/")});export{i as default};
