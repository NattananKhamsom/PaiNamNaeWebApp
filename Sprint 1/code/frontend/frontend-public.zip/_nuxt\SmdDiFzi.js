import{a6 as o,J as t,C as a}from"./DPSIKoxe.js";const s=o(e=>{if(!t("token").value&&e.path!=="/login")return a("/login")});export{s as default};
